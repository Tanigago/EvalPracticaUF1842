const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

for (let idx = 3; idx < 6; idx++) {
    console.log(numbers[idx]);
    
}


























/*


const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

for (let idx = 3; idx < 6 ; idx++) {
    console.log(numbers[idx]);
}

*/




/*PARA CREAR UNA NUEVA LISTA CON LOS NOMBRES:
const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];
const prueba = [];

for (let idx = 3; idx < 6 ; idx++) {
    console.log(numbers[idx]);
    prueba.push(numbers[idx]);
}

console.log(prueba)
*/






















/*SOLUCIONADO
const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

console.log(numbers.slice(2,5));
*/