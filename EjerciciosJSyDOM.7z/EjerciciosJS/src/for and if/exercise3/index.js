const numbers = [0,99,3,121,12,1,2];
let sum = 0;
let average = 0;

for (let item of numbers) {
    sum = sum + item;
}
    average = sum/numbers.length;
console.log("El promedio es:", average)































/*SOLUCIONADO
const numbers = [0,99,3,121,12,1,2];
let sum = 0;
let average = 0;
let lenght = numbers.length

for (let item of numbers) {
    sum = sum + item;
}
    average = sum/lenght;
console.log(average)
*/