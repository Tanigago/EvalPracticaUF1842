for (let outer = 1; outer < 10 ; outer++) {
    for (let inner = 1; inner < 11; inner++ ){
        console.log(`${outer} x ${inner} =`, outer*inner);
    }
}





























/*

for (let outer = 1; outer < 10 ; outer++) {
    for (let inner = 1; inner < 11; inner++ ){
        console.log(`${outer} x ${inner}` + " = " + (outer*inner));
    }
}

*/



























/*
for (let outer = 1; outer < 10 ; outer++ ) {
    for (let inner = 1; inner < 11; inner++ ){
        console.log(inner + "x" + outer + " = " + inner * outer);
    }
    
}
*/