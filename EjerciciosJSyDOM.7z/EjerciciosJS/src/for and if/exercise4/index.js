const numbers = [0,1,2];
let sum = numbers.length;

for (let item of numbers) {
    let sum = 0;
    sum += item;
}

console.log(sum)































/*
const numbers = [0,1,2];

for (let item of numbers) {
    let sum = numbers.length
    console.log(sum);
}
*/

































/*SOLUCIONADO
const numbers = [0,1,2];
let sum = numbers.length

for (let item of numbers) {
    let sum = 0;
    sum += item;
}

console.log(sum)
*/