# Error!

[index.js](index.js) debería de imprimir la suma de todos los números en el array ```numbers``` pero no funciona.

Ejecuta el programa, localiza el problema y soluciónalo.