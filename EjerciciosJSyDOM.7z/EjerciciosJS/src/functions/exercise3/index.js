
function power (a,b = 2){
    const total = a**b;
    return total
}

console.log(power(25))
console.log(power(8,1/3))
console.log(power(2,3))
console.log(power(5,2))
