const numbers = [11,12,13,14]

function swap (a, b, numbers){
        let temp = numbers[a];
        numbers[a] = numbers[b];
        numbers[b] = temp;
}

swap(0,3,numbers);
console.log(numbers);

swap(1,2,numbers);
console.log(numbers);
















/*SOLUCIONADO
const numbers = [11,12,13,14]

function swap (a, b, numbers) {
        let temp = numbers[a];
        numbers[a] = numbers[b];
        numbers[b] = temp;
}

swap(0,3,numbers);
console.log(numbers);

swap(1,2,numbers);
console.log(numbers);
*/